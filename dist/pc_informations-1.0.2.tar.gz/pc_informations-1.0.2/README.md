<div align="center">

# PC Info
[![Discord](https://img.shields.io/badge/Discord-5865F2?style=flat&logo=discord&logoColor=white)](https://discord.gg/rfrMnA4XCc)

Our program displays all Informations from your pc and gives you the ability to just export it and send it to the support for an example!

</div>

## Note

More infos can be found in the README file, in doubt just place your questions by direct messages @iv32. In the case that you can not sent us a message, contact us via our Discord Server (https://discord.gg/t4mYGbErAn).

## Installation

- You need:
    - Python
    - Windows 11 or Linux Mint (optional,tested)
