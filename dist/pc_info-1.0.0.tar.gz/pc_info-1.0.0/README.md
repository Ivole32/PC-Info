<div align="center">

# PC Info

[![DevSkim](https://github.com/wfxey/PC-Info/actions/workflows/devskim.yml/badge.svg)](https://github.com/wfxey/PC-Info/actions/workflows/devskim.yml) ![Python](https://img.shields.io/badge/Python-14354C?style=flat&logo=python&logoColor=white) [![License](https://img.shields.io/badge/License-MIT-blue)](#license)

[![Discord](https://img.shields.io/badge/Discord-5865F2?style=flat&logo=discord&logoColor=white)](https://discord.gg/rfrMnA4XCc)

Our program displays all Informations from your pc and gives you the ability to just export it and send it to the support for an example!

</div>

## Note

More infos can be found in the README file, in doubt just place your questions by direct messages @iv32. or @wfxey. In the case that you can not sent us a message, contact us via our Discord Server (https://discord.gg/t4mYGbErAn).
Please don't directly judge us if we've got something wrong with Licenses if you contact us we will directly solve the issue!

## Installation

- You need:
    - Python
    - Windows 11 or Linux Mint (optional,tested)
