<div align="center">

# PC Info
![Python](https://img.shields.io/badge/Python-3.13-blue?logo=python&logoColor=white)

My program displays all Informations from your pc and gives you the ability to just export it and send it to the support for an example!

Documentation: [here](https://github.com/Ivole32/PC-Info/wiki)

Quick installation: <br>
Run: ```pip install pc-informations``` <br>
Run: ```python -m pc_info``` or ```python3 -m pc_info```

</div>